/*: - Copyright :  Bulldog Ventures Inc  ©  2020 */
import UIKit

/*:

- Variables

Create a variable called name and initialize it to the name of your favorite actor, singer, or sports celebrity */
var name = "Frank Ocean"
/*:
- Displaying on the screen

Display the contents of name on the screen

 Change the value of name to your name*/
print(name)
name = "Fernando"
/*:
- Constants
 
Display the contents of name

Create a constant (let instead of var) called language and initialize it to "Swift"

Display the contents of the language constant on screen

Create 3 different constants and initialize them to hold integers of your choice. Name the constants a, b, and c

Create 3 constants that are doubles (they have decimal points) Initialize them with values of your choice. Name the constants d, e, and f*/
let Lang = "Swift"
print(Lang)

let a = 1
let b = 2
let c = 3
let d = 7
let e = 6.4
let f = 5.4
/*:
- Operators

Create an assortment of statements using the constants that you created that will perform the following actions - then display the equation and the result on the screen.*/

/*:
- Add two constants
 
-                print("a + b = " ) + (a + b)

Addition sample with at least 4 constants

Subtraction sample

Division sample

Multiplication sample*/
print("a + b = \(a + b)")
print("a - b = \(a - b)")
print("a * b = \(a * b)")
print("a / b = \(a / b)")

/*:
- If Statements
 
Use the following constants to solve the problems :*/
 
let temperature = 90
let raining = true
let time = "Morning"

/*: Write a statement that tells someone to wear shorts if it is over 80 degrees, and jeans if it is less than 80 degrees. Check with the temperature constant
 
 Check the raining constant and tell the user if they need an umbrella or not
 
 Check the time constant and if it is morning tell the user to go to school, if it is afternoon tell the user to go home, and if it is night tell the user to go to bed*/
// if raining statement
if raining == true{
    print("Hey! You're going to need an umbrella")
} else {
    print("You do not need an umbrella!:)")
}
// if time Statement
if time == "Morning"{
    print("Hey! Go to school!")
}else if(time == "Afternoon"){
    print("Go home")
} else if(time == "Night"){
    print("Go to bed")
}
/*:
- Loops

Using a for loop print the numbers from 1 to 10 on screen

Using  a while loop print the numbers from 10 to 1 on screen*/
for i in 1...10{
    print(i)
}
var count = 10

while(count > 0){
    print(count)
    count-=1
}

/*:
- Collections

Create an array that holds five strings

Create a tuple that holds two strings

Using a loop, step through one of the collections you created and print all of the items to the screen*/
var array: [String] = ["Oranges" , "mango" , "Peach" , "bannana" , "apple"]
var coord = ("Hi, hello")
for x in array {
    print(x)
}
/*:
- Functions

Create a function that takes two doubles, multiplies them, and returns the result.

Call the function, save the result in the variable "answer". Pass it two of the constants you  creataed (a, b, c, d, e, or f)*/
    func multiTwoNums(num1: Double, num2:Double) -> Double{
        return num1 * num2
    }
    var answer = multiTwoNums(num1: e, num2: f)
    print(answer)
/*:
- Closures

Create a closure that subtracts one number from another and prints the results, use the closure. You may pass it constants or numbers*/
var closure = {
    (num1: Int,  num2: Int) in
    print(num1 - num2)
}
closure(9,4)
/*:
- Enums
 
Create an enum that holds the first name of everyone in your group

Create a switch statement based on the enum that will display the birthday of the
selected person

Test it by using your own name*/
enum nameGame: String, CaseIterable {
    case name = "Angel"
    case name2 = "Fernando"
    case name3 = "Jesus"
}
var myName = nameGame.name
switch myName {
case .name, .name2:
    print("Happy Birthday, \(nameGame.name.rawValue)!")
default:
    print("Happy birthday!")
}
/*:
- Structure
 
Create a structure called Name that holds a first, middle, and last name and prints them on screen in one line with spaces between them

Create an instance of the Name structure, pass it your name, and use the instance you created to print your  name to the screen*/
    
/*:
- Class
 
Create a class called Coffee that accepts size, caffineated,  cream,  and sugar then prints the order on screen

Create an instance of the class

Use the instance of the class and call the function*/
 
struct Name {
    var fName: String
    var mName: String
    var lName: String
    
    init(strFirst: String, strMiddle: String, strLast: String
    ){
        self.fName = strFirst
        self.mName = strMiddle
        self.lName = strLast
    }
}
